% ==============================================
% function AdjSearchDomain
% ==============================================
function [SizeOfFFTSearchRegion,x0,y0,u,v,Phi]= IntegerSearch(gridxROIRange,gridyROIRange,fNormalized,gNormalized,winsize,winstepsize,file_name)

% Input initial integer search zone size
InitialGuessSatisfied = 1; % gridxBackup = gridxROIRange; gridyBackup = gridyROIRange;

% ========= Start FFT to find initial guess with integer accuracy =======
while InitialGuessSatisfied == 1
    
    prompt = '--- Whole field initial guess (0) OR Several seeds (1) initial guess? ---';
    tempNoOfInitPt = input(prompt);
    
    prompt = '--- What is your initial guess search zone size? ---';
    tempSizeOfSearchRegion = input(prompt);
    
    
    
    switch tempNoOfInitPt    
       
        case 0 % tempNoOfInitPt == 0, whole field for initial guess, 
        
        [x0,y0,u,v,Phi] = funIntegerSearch(fNormalized,gNormalized,tempSizeOfSearchRegion,gridxROIRange,gridyROIRange,winsize,winstepsize,tempNoOfInitPt,winstepsize);

        otherwise % tempNoOfInitPt ~= 0, several local seeds for initial guess
        
        % input local seeds coordinates
        figure; imshow( (imread(file_name{1}))); % surf(fNormalized,'EdgeColor','none','LineStyle','none'); view(2);
        [row1, col1] = ginput; row = floor(col1); col = floor(row1); 
        
        % initial FFT search for local seeds
        [x0,y0,u,v,Phi] = funIntegerSearch(fNormalized,gNormalized,tempSizeOfSearchRegion,gridxROIRange,gridyROIRange,winsize,winstepsize,tempNoOfInitPt,[row,col]);

        % plot-view local seeds initial results
         
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Have a look at integer search
    % --------------------------------------
    close all;
    figure; surf(u); colorbar;
    title('Displacement u','fontweight','normal')
    set(gca,'fontSize',18);
    title('$x-$displacement $u$','FontWeight','Normal','Interpreter','latex');
    axis tight; % set(gca,'XTick',[] );
    xlabel('$x$ (pixels)','Interpreter','latex'); ylabel('$y$ (pixels)','Interpreter','latex');
    set(gcf,'color','w');
    a = gca; a.TickLabelInterpreter = 'latex';
    b = colorbar; b.TickLabelInterpreter = 'latex';
    box on; colormap jet;


    figure; surf(v); colorbar;
    title('Displacement v','fontweight','normal')
    set(gca,'fontSize',18);
    title('$y-$displacement $v$','FontWeight','Normal','Interpreter','latex');
    axis tight; % set(gca,'XTick',[] );
    xlabel('$x$ (pixels)','Interpreter','latex'); ylabel('$y$ (pixels)','Interpreter','latex');
    set(gcf,'color','w');
    a = gca; a.TickLabelInterpreter = 'latex';
    b = colorbar; b.TickLabelInterpreter = 'latex';
    box on; colormap jet;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    prompt = 'Are you satisfied with initial guess with current search region? (0-yes; 1-no)';
    InitialGuessSatisfied = input(prompt);
    
end

% ======== Find some bad inital guess points ========
[u,v] = funRemoveOutliers(u,v);

% ======== Output final search region radius ========
SizeOfFFTSearchRegion = tempSizeOfSearchRegion;


