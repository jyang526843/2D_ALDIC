function [u,v,BadptRow,BadptCol] = funRemoveOutliers(u,v,varargin)

switch nargin
    case 4
        BadptRow = varargin{1}; BadptCol = varargin{2};
    otherwise
        BadptRow = []; BadptCol = [];
end


%% ==============================================
prompt = 'Do you clear bad points by setting upper/lower bounds once more? (0-yes; 1-no)';
ClearBadInitialPointsOrNot = input(prompt);

while ClearBadInitialPointsOrNot == 0
    
    prompt = 'What is your upper bound for x-displacement?';
    upperbound = input(prompt);
    [row1,col1] = find(u>upperbound);
    prompt = 'What is your lower bound for x-displacement?';
    lowerbound = input(prompt);
    [row2,col2] = find(u<lowerbound);
    prompt = 'What is your upper bound for y-displacement?';
    upperbound = input(prompt);
    [row3,col3] = find(v>upperbound);
    prompt = 'What is your lower bound for y-displacement?';
    lowerbound = input(prompt);
    [row4,col4] = find(v<lowerbound);
    
    row = [row1; row2; row3; row4]; col = [col1; col2; col3; col4];
    
    for tempi = 1:length(row)
        u(row(tempi),col(tempi))=NaN; v(row(tempi),col(tempi))=NaN;
        %f11(row(tempi),col(tempi))=NaN; f21(row(tempi),col(tempi))=NaN;
        %f12(row(tempi),col(tempi))=NaN; f22(row(tempi),col(tempi))=NaN;
    end
    
    u = inpaint_nans(u,4); v = inpaint_nans(v,4);
    %f11 = inpaint_nans(f11,4); f21 = inpaint_nans(f21,4);
    %f12 = inpaint_nans(f12,4); f22 = inpaint_nans(f22,4);
    
    % --------------------------------------
    close all;
    figure; surf(u); colorbar; title('Displacement u','fontweight','normal');
    figure; surf(v); colorbar; title('Displacement v','fontweight','normal');
    
    prompt = 'Do you clear bad points by setting upper/lower bounds? (0-yes; 1-no)';
    ClearBadInitialPointsOrNot = input(prompt);
end


%% =========
prompt = 'Do you clear bad points by directly pointing x-disp bad points? (0-yes; 1-no)';
ClearBadInitialPointsOrNot = input(prompt);

while ClearBadInitialPointsOrNot == 0
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Have a look at integer search
    % --------------------------------------
    close all;
    figure; surf(u); colorbar; view(2)
    title('Displacement u','fontweight','normal')
    % figure; surf(v); colorbar; view(2)
    % title('Displacement v','fontweight','normal')
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    [row1, col1] = ginput; row = floor(col1); col = floor(row1); 
    BadptRow=[BadptRow;row]; BadptCol=[BadptCol;col]; row=BadptRow; col=BadptCol;
    for tempi = 1:length(row)
        u(row(tempi),col(tempi))=NaN; v(row(tempi),col(tempi))=NaN;
        %f11(row(tempi),col(tempi))=NaN; f21(row(tempi),col(tempi))=NaN;
        %f12(row(tempi),col(tempi))=NaN; f22(row(tempi),col(tempi))=NaN;
    end
    u = inpaint_nans(u,4); v = inpaint_nans(v,4);
    %f11 = inpaint_nans(f11,4); f21 = inpaint_nans(f21,4);
    %f12 = inpaint_nans(f12,4); f22 = inpaint_nans(f22,4);
    
    % --------------------------------------
    close all;
    figure; surf(u); colorbar; title('Displacement u','fontweight','normal');
    % figure; surf(v); colorbar; title('Displacement v','fontweight','normal');
    
    prompt = 'Do you clear bad points by directly pointing x-disp bad points more? (0-yes; 1-no)';
    ClearBadInitialPointsOrNot = input(prompt);
    
end

prompt = 'Do you clear bad points by directly pointing y-disp bad points? (0-yes; 1-no)';
ClearBadInitialPointsOrNot = input(prompt);

while ClearBadInitialPointsOrNot == 0
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Have a look at integer search
    % --------------------------------------
    close all;
    % figure; surf(u); colorbar; view(2)
    % title('Displacement u','fontweight','normal')
    figure; surf(v); colorbar; view(2)
    title('Displacement v','fontweight','normal')
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    [row1, col1] = ginput; row = floor(col1); col = floor(row1); 
    BadptRow=[BadptRow;row]; BadptCol=[BadptCol;col]; row=BadptRow; col=BadptCol;
    
    for tempi = 1:length(row)
        u(row(tempi),col(tempi))=NaN; v(row(tempi),col(tempi))=NaN;
        %f11(row(tempi),col(tempi))=NaN; f21(row(tempi),col(tempi))=NaN;
        %f12(row(tempi),col(tempi))=NaN; f22(row(tempi),col(tempi))=NaN;
    end
    u = inpaint_nans(u,4); v = inpaint_nans(v,4);
    %f11 = inpaint_nans(f11,4); f21 = inpaint_nans(f21,4);
    %f12 = inpaint_nans(f12,4); f22 = inpaint_nans(f22,4);
    
    % --------------------------------------
    close all;
    % figure; surf(u); colorbar; title('Displacement u','fontweight','normal');
    figure; surf(v); colorbar; title('Displacement v','fontweight','normal');
    
    prompt = 'Do you clear bad points by directly pointing y-disp bad points more? (0-yes; 1-no)';
    ClearBadInitialPointsOrNot = input(prompt);
    
end

% 
% prompt = 'Do you clear bad points by directly pointing F11 bad points? (0-yes; 1-no)';
% ClearBadInitialPointsOrNot = input(prompt);
% 
% while ClearBadInitialPointsOrNot == 0
%     
%     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     % Have a look at integer search
%     % --------------------------------------
%     close all;
%     figure; surf(f11); colorbar; view(2)
%     title('Displacement u','fontweight','normal')
%     % figure; surf(v); colorbar; view(2)
%     % title('Displacement v','fontweight','normal')
%     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     
%     [row1, col1] = ginput; 
%     row = floor(col1); col = floor(row1);
%     
%     for tempi = 1:length(row)
%         u(row(tempi),col(tempi))=NaN; v(row(tempi),col(tempi))=NaN;
%         f11(row(tempi),col(tempi))=NaN; f21(row(tempi),col(tempi))=NaN;
%         f12(row(tempi),col(tempi))=NaN; f22(row(tempi),col(tempi))=NaN;
%     end
%     u = inpaint_nans(u,4); v = inpaint_nans(v,4);
%     f11 = inpaint_nans(f11,4); f21 = inpaint_nans(f21,4);
%     f12 = inpaint_nans(f12,4); f22 = inpaint_nans(f22,4);
%     
%     % --------------------------------------
%     close all;
%     figure; surf(f11); colorbar; title('Displacement u','fontweight','normal');
%     % figure; surf(v); colorbar; title('Displacement v','fontweight','normal');
%     
%     prompt = 'Do you clear bad points by directly pointing x-disp bad points more? (0-yes; 1-no)';
%     ClearBadInitialPointsOrNot = input(prompt);
%     
% end
% 
% 
% prompt = 'Do you clear bad points by directly pointing F21 bad points? (0-yes; 1-no)';
% ClearBadInitialPointsOrNot = input(prompt);
% 
% while ClearBadInitialPointsOrNot == 0
%     
%     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     % Have a look at integer search
%     % --------------------------------------
%     close all;
%     figure; surf(f21); colorbar; view(2)
%     title('Displacement u','fontweight','normal')
%     % figure; surf(v); colorbar; view(2)
%     % title('Displacement v','fontweight','normal')
%     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     
%     [row1, col1] = ginput; 
%     row = floor(col1); col = floor(row1);
%     
%     for tempi = 1:length(row)
%         u(row(tempi),col(tempi))=NaN; v(row(tempi),col(tempi))=NaN;
%         f11(row(tempi),col(tempi))=NaN; f21(row(tempi),col(tempi))=NaN;
%         f12(row(tempi),col(tempi))=NaN; f22(row(tempi),col(tempi))=NaN;
%     end
%     u = inpaint_nans(u,4); v = inpaint_nans(v,4);
%     f11 = inpaint_nans(f11,4); f21 = inpaint_nans(f21,4);
%     f12 = inpaint_nans(f12,4); f22 = inpaint_nans(f22,4);
%     
%     % --------------------------------------
%     close all;
%     figure; surf(f21); colorbar; title('Displacement u','fontweight','normal');
%     % figure; surf(v); colorbar; title('Displacement v','fontweight','normal');
%     
%     prompt = 'Do you clear bad points by directly pointing x-disp bad points more? (0-yes; 1-no)';
%     ClearBadInitialPointsOrNot = input(prompt);
%     
% end
% 
% 
% prompt = 'Do you clear bad points by directly pointing F12 bad points? (0-yes; 1-no)';
% ClearBadInitialPointsOrNot = input(prompt);
% 
% while ClearBadInitialPointsOrNot == 0
%     
%     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     % Have a look at integer search
%     % --------------------------------------
%     close all;
%     figure; surf(f12); colorbar; view(2)
%     title('Displacement u','fontweight','normal')
%     % figure; surf(v); colorbar; view(2)
%     % title('Displacement v','fontweight','normal')
%     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     
%     [row1, col1] = ginput; 
%     row = floor(col1); col = floor(row1);
%     
%     for tempi = 1:length(row)
%         u(row(tempi),col(tempi))=NaN; v(row(tempi),col(tempi))=NaN;
%         f11(row(tempi),col(tempi))=NaN; f21(row(tempi),col(tempi))=NaN;
%         f12(row(tempi),col(tempi))=NaN; f22(row(tempi),col(tempi))=NaN;
%     end
%     u = inpaint_nans(u,4); v = inpaint_nans(v,4);
%     f11 = inpaint_nans(f11,4); f21 = inpaint_nans(f21,4);
%     f12 = inpaint_nans(f12,4); f22 = inpaint_nans(f22,4);
%     
%     % --------------------------------------
%     close all;
%     figure; surf(f12); colorbar; title('Displacement u','fontweight','normal');
%     % figure; surf(v); colorbar; title('Displacement v','fontweight','normal');
%     
%     prompt = 'Do you clear bad points by directly pointing x-disp bad points more? (0-yes; 1-no)';
%     ClearBadInitialPointsOrNot = input(prompt);
%     
% end
% 
% 
% prompt = 'Do you clear bad points by directly pointing F22 bad points? (0-yes; 1-no)';
% ClearBadInitialPointsOrNot = input(prompt);
% 
% while ClearBadInitialPointsOrNot == 0
%     
%     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     % Have a look at integer search
%     % --------------------------------------
%     close all;
%     figure; surf(f22); colorbar; view(2)
%     title('Displacement u','fontweight','normal')
%     % figure; surf(v); colorbar; view(2)
%     % title('Displacement v','fontweight','normal')
%     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     
%     [row1, col1] = ginput; 
%     row = floor(col1); col = floor(row1);
%     
%     for tempi = 1:length(row)
%         u(row(tempi),col(tempi))=NaN; v(row(tempi),col(tempi))=NaN;
%         f11(row(tempi),col(tempi))=NaN; f21(row(tempi),col(tempi))=NaN;
%         f12(row(tempi),col(tempi))=NaN; f22(row(tempi),col(tempi))=NaN;
%     end
%     u = inpaint_nans(u,4); v = inpaint_nans(v,4);
%     f11 = inpaint_nans(f11,4); f21 = inpaint_nans(f21,4);
%     f12 = inpaint_nans(f12,4); f22 = inpaint_nans(f22,4);
%     
%     % --------------------------------------
%     close all;
%     figure; surf(f22); colorbar; title('Displacement u','fontweight','normal');
%     % figure; surf(v); colorbar; title('Displacement v','fontweight','normal');
%     
%     prompt = 'Do you clear bad points by directly pointing x-disp bad points more? (0-yes; 1-no)';
%     ClearBadInitialPointsOrNot = input(prompt);
    
end


