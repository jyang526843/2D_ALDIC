%% Integer Search

function [x,y,u,v,Phi] = funIntegerSearch(f,g,tempSizeOfSearchRegion,gridx,gridy,winsize,winstepsize,tempNoOfInitPt,varargin)

%(f,g,tempSizeOfSearchRegion,gridx,gridy,winsize,winstepsize)

switch tempNoOfInitPt % 0- whole field; 1- several seeds points;
    case 0 % 0- whole field;
        
        gridxBackup = gridx; gridyBackup = gridy;
        
        % may lose boundary regions
        if gridx(1)-tempSizeOfSearchRegion-0.5*winsize < 1
            gridx(1) = gridx(1) +tempSizeOfSearchRegion+1;
        end
        if gridy(1)-tempSizeOfSearchRegion-0.5*winsize/2 < 1
            gridy(1) = gridy(1) +tempSizeOfSearchRegion+1;
        end
        if gridx(end)+0.5*winsize+tempSizeOfSearchRegion > size(f,1)
            gridx(end) = gridx(end) -tempSizeOfSearchRegion-1;
        end
        if gridy(end)+0.5*winsize+tempSizeOfSearchRegion > size(f,2) 
            gridy(end) = gridy(end) -tempSizeOfSearchRegion-1;
        end
        
        [x,y,u,v,Phi] = funIntegerSearchWholeField(f,g,tempSizeOfSearchRegion,gridx,gridy,winsize,winstepsize);
%         xList = gridxBackup(1):winstepsize:gridxBackup(end); yList = gridyBackup(1):winstepsize:gridyBackup(end);
%         [x,y] = meshgrid(xList,yList);
%         u = gridfit(xtemp,ytemp,utemp,xList,yList,'smooth',1,'interp','bilinear','regularizer','springs');
%         v = gridfit(xtemp,ytemp,vtemp,xList,yList,'smooth',1,'interp','bilinear','regularizer','springs');
%         Phi = gridfit(xtemp,ytemp,Phitemp,xList,yList,'smooth',1,'interp','bilinear','regularizer','springs');
        
    case 1 % 1- several seeds points;
        seedPtCoords = varargin{1}; uSeedPt = zeros(size(seedPtCoords,1),1); vSeedPt = uSeedPt; PhiSeedPt = uSeedPt;
        for tempi = 1:length(seedPtCoords)
            
            if ceil(seedPtCoords(tempi,1)-winsize/2)-tempSizeOfSearchRegion < 1 || ...
                    floor(seedPtCoords(tempi,1)+winsize/2)+tempSizeOfSearchRegion > size(g,1) || ...
                    ceil(seedPtCoords(tempi,2)-winsize/2)-tempSizeOfSearchRegion < 1 || ...
                    floor(seedPtCoords(tempi,2)+winsize/2)+tempSizeOfSearchRegion > size(g,2)
                continue;
            else
            
                C = f(ceil(seedPtCoords(tempi,1)-winsize/2):floor(seedPtCoords(tempi,1)+winsize/2), ...
                      ceil(seedPtCoords(tempi,2)-winsize/2):floor(seedPtCoords(tempi,2)+winsize/2));
                D = g(ceil(seedPtCoords(tempi,1)-winsize/2)-tempSizeOfSearchRegion:floor(seedPtCoords(tempi,1)+winsize/2)+tempSizeOfSearchRegion, ...
                     ceil(seedPtCoords(tempi,2)-winsize/2)-tempSizeOfSearchRegion:floor(seedPtCoords(tempi,2)+winsize/2)+tempSizeOfSearchRegion);  

                XCORRF2OfCD0 = normxcorr2(C,D);

                [v1temp, u1temp, max_f] = findpeak(XCORRF2OfCD0(winsize:end-winsize+1,winsize:end-winsize+1),1);

                zero_disp = ceil(size(XCORRF2OfCD0(winsize:end-winsize+1,winsize:end-winsize+1))/2);

                uSeedPt(tempi) = u1temp-zero_disp(1);
                vSeedPt(tempi) = v1temp-zero_disp(2);
                PhiSeedPt(tempi) = max_f;
            end
            
        end
        
        xList = gridx(1):winstepsize:gridx(end); yList = gridy(1):winstepsize:gridy(end);
        [x,y] = meshgrid(xList,yList);
        %bc = Spline2D('bicubic',X,Y,ZZ);
        u = gridfit(seedPtCoords(:,1),seedPtCoords(:,2),uSeedPt,xList,yList,...
            'smooth',100,'interp','bicubic','regularizer','springs');
        v = gridfit(seedPtCoords(:,1),seedPtCoords(:,2),vSeedPt,xList,yList,...
            'smooth',100,'interp','bicubic','regularizer','springs');
        Phi = gridfit(seedPtCoords(:,1),seedPtCoords(:,2),PhiSeedPt,xList,yList,...
            'smooth',100,'interp','bicubic','regularizer','springs');
        
    otherwise
        disp('wrong input in IntegerSearch!');
end

end

function [x,y,u,v,Phi] = funIntegerSearchWholeField(f,g,tempSizeOfSearchRegion,gridx,gridy,winsize,winstepsize)

cj1 = 1; ci1 = 1; % index to count main loop
sizeOfx1 = floor((gridx(2)-gridx(1)-winsize)/winstepsize)+1;
sizeOfx2 = floor((gridy(2)-gridy(1)-winsize)/winstepsize)+1;
disp(['Init search using FFT cross correlation on grid: ',num2str(sizeOfx1),'x',num2str(sizeOfx2)]);
x = zeros(sizeOfx2,sizeOfx1); y = x; u = x; v = x; Phi = x;

for jj = gridy(1) : winstepsize : gridy(end)-winsize
    % jj is for y -or- vertical direction of images
    
    for ii = gridx(1) : winstepsize : gridx(end)-winsize
        % ii is for x -or- horizontal direction of images
        
        C = f(ii:ii+winsize, jj:jj+winsize);
        
        D = g(ii-tempSizeOfSearchRegion:ii+winsize+tempSizeOfSearchRegion, ...
            jj-tempSizeOfSearchRegion:jj+winsize+tempSizeOfSearchRegion);
        
        XCORRF2OfCD0 = normxcorr2(C,D);
        
        [v1temp, u1temp, max_f] = findpeak(XCORRF2OfCD0(winsize:end-winsize+1,winsize:end-winsize+1),1);
        
        % I tried following code, unfortunately it doesn't work very well
        % [v1temp1, u1temp1, max_f1] = findpeak(XCORRF2OfCD0(winsize:end-winsize+1,winsize:end-winsize+1),1);
        % [v1temp2, u1temp2, max_f2] = findpeak(XCORRF2OfCD0(winsize:end-winsize+1,winsize:end-winsize+1),0);
        %
        % if max_f2 > 0.999
        %    v1temp = v1temp2; u1temp = u1temp2; max_f = max_f2;
        % else
        %    v1temp = v1temp1; u1temp = u1temp1; max_f = max_f1;
        % end
        
        zero_disp = ceil(size(XCORRF2OfCD0(winsize:end-winsize+1,winsize:end-winsize+1))/2);
        
        u(cj1,ci1)   = u1temp-zero_disp(1);
        v(cj1,ci1)   = v1temp-zero_disp(2);
        Phi(cj1,ci1) = max_f;
        
        y(cj1,ci1)=(jj+jj+winsize)/2;   % vertical position in image
        x(cj1,ci1)=(ii+ii+winsize)/2;   % horizontal position in image
        
        % Update counters
        ci1 = ci1 + 1;  % ci1 is moving horizontally for subsets
        
    end
    
    ci1=1; cj1=cj1+1;  % cj1 is moving vertically for subsets
    
end
end

% fprintf('Finish integers search!\n');
% figure, surf(Phi)