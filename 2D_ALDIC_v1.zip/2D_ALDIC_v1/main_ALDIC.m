% ---------------------------------------------
% Augmented Lagrangian DIC
% Author: Jin Yang, PhD. Caltech
% Contact: yangjin@caltech.edu
% 2015.04,06,07; 2016.03,04
% ---------------------------------------------

%% Section 1
% ====== Clear MATLAB environment & mex set up Spline interpolation ======
close all; clear; clc; 
fprintf('------------ Section 1 Start ------------ \n')
setenv('MW_MINGW64_LOC','C:\TDM-GCC-64')
% cd("./Splines_interp/lib_matlab"); CompileLib; % % mex bi-cubic spline interpolations
% cd("../../"); addpath("./Splines_interp/lib_matlab");
mex -O ba_interp2.cpp; % dbstop if error % % Old version codes.
fprintf('------------ Section 1 Done ------------ \n \n')


%% Section 2
fprintf('------------ Section 2 Start ------------ \n')
% ====== Read images ======
[file_name,f,g,winsize,winstepsize,gridxROIRange,gridyROIRange] = ReadImage;
% ====== Cncomment the behind line and change the value you want ======
% gridxROIRange = [gridxROIRange1, gridxROIRange2]; gridyROIRange = [gridyROIRange1, gridyROIRange2];
% ====== Normalize images ======
[fNormalized,gNormalized,gridxROIRange,gridyROIRange] = funNormalizeImg(f,g,gridxROIRange,gridyROIRange);
fprintf('------------ Section 2 Done ------------ \n \n')


%% Section 3
fprintf('------------ Section 3 Start ------------ \n')
% ====== Integer Search ======
[SizeOfFFTSearchRegion,x0,y0,u,v,Phi]= IntegerSearch(gridxROIRange,gridyROIRange,fNormalized,gNormalized,winsize,winstepsize,file_name);
% ====== FEM mesh set up ======
[coordinatesFEM,elementsFEM,coordinates,elements,dirichlet,neumann,x0,y0] = MeshSetUp(x0,y0,winstepsize);
% ====== Initial Value ======
U0 = Init(u,v,Phi,x0,y0,0); PlotuvInit;  
%Plotdisp_show(U0,[coordinatesFEM(:,1),size(fNormalized,2)+1-coordinatesFEM(:,2)],elementsFEM); % Plot initial values
% ====== Spline interpolation images ======
%[imgfNormalizedbc,imggNormalizedbc,imgSize,DfAxis] = funImgGradient(fNormalized,gNormalized);
Df = funImgGradient(fNormalized,gNormalized); % % using finite difference;
% ====== Compute f(X)-g(x+u) ======
% PlotImgDiff(x0,y0,u,v,fNormalized,gNormalized);
fprintf('------------ Section 3 Done ------------ \n \n')


%% Section 4
fprintf('------------ Section 4 Start ------------ \n')
% ====== ALStep 1 Subproblem1: Local Subset DIC ======
mu = 0; beta = 0; tol = 1e-6; ALSolveStep = 1; ALSub1Time = zeros(6,1); ALSub2Time = zeros(6,1); ConvItPerEle = zeros(size(coordinatesFEM,1),6);
disp(['***** Start step',num2str(ALSolveStep),' Subproblem1 *****'])
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ------ Assign parpool cluster No ------
prompt = 'How many parallel pools to open? (Put in 1 if no parallel computing)';  ClusterNo = input(prompt);
% ------ Start Local DIC IC-GN iteration ------
[USubpb1,FSubpb1,HtempPar,ALSub1Timetemp,ConvItPerEletemp] = LocalICGN(U0,coordinatesFEM,...
    Df,fNormalized,gNormalized,winsize,winstepsize,tol,'GaussNewton',ClusterNo);
ALSub1Time(ALSolveStep) = ALSub1Timetemp; ConvItPerEle(:,ALSolveStep) = ConvItPerEletemp; clear ALSub1Timetemp ConvItPerEletemp; toc
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ------  Manually find some bad points from Local Subset ICGN step ------
disp('--- Start to manually remove bad points ---')
USubpb1World = USubpb1; USubpb1World(2:2:end) = -USubpb1(2:2:end); Plotuv(USubpb1World,x0,y0World);
u = reshape(USubpb1(1:2:end),size(x0,1),size(x0,2)); v = reshape(USubpb1(2:2:end),size(x0,1),size(x0,2)); 
[u,v,Local_BadptRow,Local_BadptCol] = funRemoveOutliers(u,v); 
USubpb1(1:2:end) = reshape(u,size(elements,1),1); USubpb1(2:2:end) = reshape(v,size(elements,1),1);
disp('--- Remove bad points done ---')
% ------ Plot ------
USubpb1World = USubpb1; USubpb1World(2:2:end) = -USubpb1(2:2:end); 
FSubpb1World = FSubpb1; % FSubpb1World(2:2:end) = -FSubpb1(2:2:end);
close all; Plotuv(USubpb1World,x0,y0World); Plotdisp_show(USubpb1World,coordinatesFEMWorld,elementsFEM);
Plotstrain_show(FSubpb1World,coordinatesFEMWorld,elementsFEM);
save(['Subpb1_step',num2str(ALSolveStep)],'USubpb1','FSubpb1');
fprintf('------------ Section 4 Done ------------ \n \n')


%% Section 5
fprintf('------------ Section 5 Start ------------ \n')
% ======= ALStep 1 Subproblem 2: Global constraint =======
% ------ Smooth displacements for better F ------
DispFilterSize=0; DispFilterStd = 0; StrainFilterSize = 0; StrainFilterStd =0; LevelNo = 1;
FSubpb1 = funSmoothStrain(FSubpb1,coordinatesFEM,elementsFEM,winstepsize,StrainFilterSize,StrainFilterStd);
% % ------ Smooth displacements ------
% prompt = 'Do you want to smooth displacement? (0-yes; 1-no)';
% DoYouWantToSmoothOnceMore = input(prompt); DispFilterSize=0; DispFilterStd=0;
% if DoYouWantToSmoothOnceMore == 0,USubpb1 = funSmoothDisp(USubpb1,coordinatesFEM,elementsFEM,winstepsize,DispFilterSize,DispFilterStd);end

% ====== Build sparse finite difference operator ======
disp('Assemble finite difference operator D');
M = size(x0,1); N = size(x0,2);
Rad = 1; D = funDerivativeOp((M-2*Rad),(N-2*Rad),winstepsize); % D = sparse(4*(M-2*Rad)*(N-2*Rad), 2*(M-2*Rad)*(N-2*Rad));
tic; D2 = funDerivativeOp(M,N,winstepsize); toc
disp('Finish assembling finite difference operator D');
  
% ====== Define penalty parameter ======
mu = 1e-3; beta = 0.1*(winstepsize)^2*mu; udual = 0*FSubpb1; vdual = 0*USubpb1; 
disp(['***** Start step',num2str(ALSolveStep),' Subproblem2 *****'])
%%%%%%%%%%%%% Comment for using finite difference approximation %%%%%%%%%%%%%%
tic; a = FSubpb1-udual; b = USubpb1-vdual;
Rad = 1; FDNeumannBC; % Find coordinatesFEM that belong to (x(Rad+1:M-Rad,Rad+1:N-Rad),y(Rad+1:M-Rad,Rad+1:N-Rad))
tempAMatrixSub2 = (beta*(D')*D) + mu*speye(2*(M-2*Rad)*(N-2*Rad));
USubpb2temp = (tempAMatrixSub2) \ (beta*D'*atemp + mu*btemp) ;
USubpb2 = USubpb1; USubpb2(temp4) = USubpb2temp; toc
%%%%%%%%%%%%%% End of using finite difference approximation %%%%%%%%%%%%%%

% ------- Before computing strain, we smooth the displacement field -------
USubpb2 = funSmoothDisp(USubpb2,coordinatesFEM,elementsFEM,x0,y0,winstepsize,DispFilterSize,DispFilterStd);
% ------- Compute strain field -------- 
FSubpb2 = D2*USubpb2; % D2 = funDerivativeOp(M,N,winstepsize);
% FSubpb3 = Global_NodalStrainAvg(coordinatesFEM,elementsFEM,USubpb3);
% ------- Smooth strain field --------
FSubpb2 = funSmoothStrain(FSubpb2,coordinatesFEM,elementsFEM,winstepsize,StrainFilterSize,StrainFilterStd);

% ------- Save data ------
save(['Subpb2_step',num2str(ALSolveStep)],'USubpb2','FSubpb2');

% ------ Plot ------
USubpb2World = USubpb2; USubpb2World(2:2:end) = -USubpb2(2:2:end); 
FSubpb2World = FSubpb2; % FSubpb1World(2:2:end) = -FSubpb1(2:2:end);
close all; Plotuv(USubpb2World,x0,y0World); Plotdisp_show(USubpb2World,coordinatesFEMWorld,elementsFEM);
Plotstrain_show(FSubpb2World,coordinatesFEMWorld,elementsFEM);

% ======= Update dual variables =======
udualtemp1 = (FSubpb2 - FSubpb1); udualtemp2 = udualtemp1(temp3);
vdualtemp1 = (USubpb2 - USubpb1); vdualtemp2 = vdualtemp1(temp4);
udual = zeros(4*M*N,1); vdual = zeros(2*M*N,1);
udual(temp3) = udualtemp2; vdual(temp4) = vdualtemp2;
save(['uvdual_step',num2str(ALSolveStep)],'udual','vdual');
fprintf('------------ Section 5 Done ------------ \n \n')
 

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Section 6
fprintf('------------ Section 6 Start ------------ \n')
% ==================== Global AL Loop ==========================
ALSolveStep = 1; tol2 = 1e-4; UpdateY = 1e4; CrackOrNot = 0; CrackPath1 = [0,0]; CrackPath2 = [0,0]; CrackTip = [0,0]; 
HPar = cell(21,1); for tempj = 1:21, HPar{tempj} = HtempPar(:,tempj); end

while (ALSolveStep < 6)
    ALSolveStep = ALSolveStep + 1;  % Update using the last step
    %%%%%%%%%%%%%%%%%%%%%%% Subproblem 1 %%%%%%%%%%%%%%%%%%%%%%%%%
    disp(['***** Start step',num2str(ALSolveStep),' Subproblem1 *****'])
    tic;[USubpb1, HPar, ALSub1Timetemp, ConvItPerEletemp] = Subpb1(USubpb2,FSubpb2,udual,vdual,coordinatesFEM,...
    Df,fNormalized,gNormalized,winsize,mu,beta,HPar,ALSolveStep,tol,'GaussNewton',ClusterNo);
    FSubpb1 = FSubpb2; toc
    ALSub1Time(ALSolveStep) = ALSub1Timetemp; ConvItPerEle(:,ALSolveStep) = ConvItPerEletemp; clear ALSub1Timetemp ConvItPerEletemp;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % ------  Manually find some bad points from Local Subset ICGN step ------
    % disp('--- Start to manually remove bad points ---')
    % close all; Plotuv(USubpb1,x0,y0);
    % u = reshape(USubpb1(1:2:end),M,N); v = reshape(USubpb1(2:2:end),M,N);
    % [u,v,Subpb1_BadptRow,Subpb1_BadptCol] = funRemoveOutliers(u,v,Local_BadptRow,Local_BadptCol); 
    % disp('--- Remove bad points done ---')
    % USubpb1(1:2:end) = reshape(u,size(elements,1),1); USubpb1(2:2:end) = reshape(v,size(elements,1),1);
    % close all; Plotuv(USubpb1,x0,y0); Plotdisp_show(USubpb1,elementsFEM,coordinatesFEM);
    save(['Subpb1_step',num2str(ALSolveStep)],'USubpb1','FSubpb1');
    USubpb1 = funSmoothDisp(USubpb1,coordinatesFEM,elementsFEM,x0,y0,winstepsize,DispFilterStd,DispFilterSize,LevelNo);
     
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % ============== Subproblem 2 ==============
    disp(['***** Start step',num2str(ALSolveStep),' Subproblem2 *****'])
    % ------- using finite difference approximation --------
    tic; a = FSubpb1-udual; b = USubpb1-vdual; atemp = a(temp3); btemp = b(temp4);
    USubpb2temp = (tempAMatrixSub2) \ (beta*D'*atemp + mu*btemp) ;
    USubpb2 = USubpb1; USubpb2(temp4) = USubpb2temp; toc
    % ------- End of using finite difference approximation --------
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % ------- Before computing strain, we smooth the displacement field -------
    % USubpb2 = funSmoothDisp(USubpb2,coordinatesFEM,elementsFEM,x0,y0,winstepsize,DispFilterSize,DispFilterStd);
    % ------- Compute strain field --------
    FSubpb2 = D2*USubpb2; % D2 = funDerivativeOp(M,N,winstepsize);
    % FSubpb3 = Global_NodalStrainAvg(coordinatesFEM,elementsFEM,USubpb3);
    % ------- Smooth strain field --------
    FSubpb2 = funSmoothStrain(FSubpb2,coordinatesFEM,elementsFEM,winstepsize,StrainFilterSize,StrainFilterStd);

    save(['Subpb2_step',num2str(ALSolveStep)],'USubpb2','FSubpb2');
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Compute norm of UpdateY
    USubpb2_Old = load(['Subpb2_step',num2str(ALSolveStep-1)],'USubpb2');
    USubpb2_New = load(['Subpb2_step',num2str(ALSolveStep)],'USubpb2');
    UpdateY = norm((USubpb2_Old.USubpb2 - USubpb2_New.USubpb2), 2)/sqrt(size(USubpb2_Old.USubpb2,1));
    
    USubpb1_Old = load(['Subpb1_step',num2str(ALSolveStep-1)],'USubpb1');
    USubpb1_New = load(['Subpb1_step',num2str(ALSolveStep)],'USubpb1');
    UpdateY2 = norm((USubpb1_Old.USubpb1 - USubpb1_New.USubpb1), 2)/sqrt(size(USubpb1_Old.USubpb1,1));
    
    disp(['Update local step  = ',num2str(UpdateY2)]);
    disp(['Update global step = ',num2str(UpdateY)]);
    fprintf('*********************************** \n \n');
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Update dual variables------------------------------
    udualtemp1 =  (FSubpb2 - FSubpb1); udualtemp2 = udualtemp1(temp3);
    vdualtemp1 =  (USubpb2 - USubpb1); vdualtemp2 = vdualtemp1(temp4);
    udual(temp3) = udual(temp3)+udualtemp2; 
    vdual(temp4) = vdual(temp4)+vdualtemp2;
    
    save(['uvdual_step',num2str(ALSolveStep)],'udual','vdual');
    
    if UpdateY < tol2 || UpdateY2 < tol2
        break
    end
     
end
fprintf('------------ Section 6 Done ------------ \n \n')


%% Section 7
fprintf('------------ Section 7 Start ------------ \n')
% ====== Check convergence ======
ALSolveStep1 = min(6,ALSolveStep);

for ALSolveStep = 1:ALSolveStep1
    USubpb2 = load(['Subpb2_step',num2str(ALSolveStep )],'USubpb2');
    USubpb1 = load(['Subpb1_step',num2str(ALSolveStep )],'USubpb1');
    UpdateY = norm((USubpb2.USubpb2 - USubpb1.USubpb1), 2)/sqrt(length(USubpb2.USubpb2));
    disp(num2str(UpdateY));
end
disp('========');
for ALSolveStep = 1:ALSolveStep1
    FSubpb1 = load(['Subpb1_step',num2str(ALSolveStep )],'FSubpb1');
    FSubpb2 = load(['Subpb2_step',num2str(ALSolveStep )],'FSubpb2');
    UpdateF = norm((FSubpb1.FSubpb1 - FSubpb2.FSubpb2), 2)/sqrt(length(FSubpb1.FSubpb1));
    disp(num2str(UpdateF));
end
disp('========');
for ALSolveStep = 2:ALSolveStep1
    USubpb2_Old = load(['Subpb2_step',num2str(ALSolveStep-1)],'USubpb2');
    USubpb2_New = load(['Subpb2_step',num2str(ALSolveStep)],'USubpb2');
    UpdateY = norm((USubpb2_Old.USubpb2 - USubpb2_New.USubpb2), 2)/sqrt(length(USubpb2.USubpb2));
    disp(num2str(UpdateY));
end
disp('========');
for ALSolveStep = 2:ALSolveStep1
    uvdual_Old = load(['uvdual_step',num2str(ALSolveStep-1)],'udual');
    uvdual_New = load(['uvdual_step',num2str(ALSolveStep)],'udual');
    UpdateW = norm((uvdual_Old.udual - uvdual_New.udual), 2)/sqrt(length(uvdual_Old.udual));
    disp(num2str(UpdateW));
end
disp('========');
for ALSolveStep = 2:ALSolveStep1
    uvdual_Old = load(['uvdual_step',num2str(ALSolveStep-1)],'vdual');
    uvdual_New = load(['uvdual_step',num2str(ALSolveStep)],'vdual');
    Updatev = norm((uvdual_Old.vdual - uvdual_New.vdual), 2)/sqrt(length(uvdual_Old.vdual));
    disp(num2str(Updatev));
end
fprintf('------------ Section 7 Done ------------ \n \n')


%% Section 8
fprintf('------------ Section 8 Start ------------ \n')
 
% ------ Delete temp files ------
for tempi = 1:ALSolveStep
    file_name_Subpb1 = ['Subpb1_step',num2str(tempi),'.mat'];
    file_name_Subpb2 = ['Subpb2_step',num2str(tempi),'.mat'];
    file_name_dual = ['uvdual_step',num2str(tempi),'.mat'];
    delete(file_name_Subpb1); delete(file_name_Subpb2); delete(file_name_dual);
end

% ------ Plotting and Compute Strain-------
M = size(x0,1); N = size(x0,2);
if size(USubpb2,1) == 1
    ULocal = USubpb2_New.USubpb2; FLocal = FSubpb2.FSubpb2; 
else
    ULocal = USubpb2; FLocal = FSubpb2;
end
% ULocal(1:2:end)= -ULocal(1:2:end); 
% FLocal(1:4:end)= -1*FLocal(1:4:end); FLocal(3:4:end)= -1*FLocal(3:4:end); % because u is flipped sign
UWorld = ULocal; UWorld(2:2:end)= -UWorld(2:2:end); FWorld = FLocal; close all; Plotuv(UWorld,x0,y0World);
% tic; D = funDerivativeOp(M,N,winstepsize); toc

% ------ Smooth displacements ------
prompt = 'Do you want to smooth displacement? (0-yes; 1-no)';
DoYouWantToSmoothOnceMore = input(prompt); DispFilterSize=0; DispFilterStd=0;
while DoYouWantToSmoothOnceMore == 0
    ULocal = funSmoothDisp(ULocal,coordinatesFEM,elementsFEM,x0,y0,winstepsize,DispFilterSize,DispFilterStd);
    close all; Plotuv(ULocal,x0,y0); 
    DoYouWantToSmoothOnceMore = input(prompt);
end
% ------ Choose strain computation method ------
prompt = 'What method to use to compute strain? (0-None; 1-Finite difference; 2-Plane fitting)';
MethodToComputeStrain = input(prompt);
while (MethodToComputeStrain ~= 0) && (MethodToComputeStrain ~= 1) && (MethodToComputeStrain ~= 2)
    disp('Wrong input!')
    prompt = 'What method to use to compute strain? (0-None; 1-Finite difference; 2-Plane fitting)';
    MethodToComputeStrain = input(prompt);
end
% ----- Compute strain field ------
ComputeStrain;

% ------ Plot disp ------
Plotdisp_show(UWorld,coordinatesFEMWorld,elementsFEM);

% ------ Plot strain ------
Plotstrain0(FStraintemp,x0(1+Rad:M-Rad,1+Rad:N-Rad),y0(1+Rad:M-Rad,1+Rad:N-Rad),size(fNormalized)); 

fprintf('------------ Section 8 Done ------------ \n \n')


%% ------- Store images ------
% imgNo = 0570;
% figure(3); colormap jet; caxis auto; print(['Can',num2str(imgNo),'_WS',num2str(winsize),'_ST',num2str(winstepsize),'_DispU'],'-djpeg','-r600');
% figure(4); colormap jet; caxis auto; print(['Can',num2str(imgNo),'_WS',num2str(winsize),'_ST',num2str(winstepsize),'_DispV'],'-djpeg','-r600')
% figure(5); colormap coolwarm(32); caxis([-0.002,0.002]); print(['Can',num2str(imgNo),'_WS',num2str(winsize),'_ST',num2str(winstepsize),'_exx_StrainMethod1'],'-djpeg','-r600')
% figure(6); colormap coolwarm(32); caxis([-0.002,0.002]); print(['Can',num2str(imgNo),'_WS',num2str(winsize),'_ST',num2str(winstepsize),'_exy_StrainMethod1'],'-djpeg','-r600')
% figure(7); colormap coolwarm(32); caxis([-0.002,0.002]); print(['Can',num2str(imgNo),'_WS',num2str(winsize),'_ST',num2str(winstepsize),'_eyy_StrainMethod1'],'-djpeg','-r600') % caxis([0.0,0.015]);
% figure(8); colormap coolwarm(32); caxis([-0.002,0.002]); print(['Can',num2str(imgNo),'_WS',num2str(winsize),'_ST',num2str(winstepsize),'_maxshear_StrainMethod1'],'-djpeg','-r600')
% 
% mean(FStraintemp(1:4:end)) % -0.0029(57939_WS20ST10) -0.0029(57939_WS40ST10) -5.03e-4(57383_WS20ST10)  -5.02e-4(57383_WS40ST10)
% mean(FStraintemp(4:4:end)) % 0.0056(57939_WS20ST10) 0.0056(57939_WS40ST10) 3.804e-4(57383_WS20ST10)  3.85e-4(57383_WS20ST10)
% 0.5*(mean(FStraintemp(2:4:end))+mean(FStraintemp(3:4:end))) % -5.7438e-4(57939_WS20ST10)  -5.7665e-4(57939_WS40ST10) -1.06e-4(57383_WS20ST10)  -1.0456e-4(57383_WS40ST10)

%% Save data
% save Star4_WS9_ST8_Ref2.mat USubpb2 FSubpb2 SizeOfFFTSearchRegion x0 y0 gridxROIRange gridyROIRange ...
%     StrainFilterSize StrainFilterStd DispFilterSize DispFilterStd ...
%     ALSub1Time ALSub2Time ALSolveStep;


